<html>

    <head>
        <meta Charset="UTF-8">
        <title></title>
    </head>
<body>
    <?php
        echo 'Hello World';
    ?>
   </body>
</html>

